import pkg from '../../package.json';

export const commandName = 'ut-agent';
export const projectName = 'UT Agent';
export const version = pkg.version;