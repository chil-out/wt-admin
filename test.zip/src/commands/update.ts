import { command } from 'cleye';
import { execaCommand } from 'execa';
import { dim } from 'kolorist';

export default command(
  {
    name: 'update',
    help: {
      description: 'Update to the latest version',
    },
  },
  async () => {
    console.log('start run command...');
    const command = `npm update -g @bin.ma/ut-agent`;
    console.log(dim(`Running: ${command}`));
    console.log('');
    await execaCommand(command, {
      stdio: 'inherit',
      shell: process.env.SHELL || true,
    }).catch(() => {
      console.log(dim('Failed to update. Please try again later.'));
    });
    console.log('success run command...');
  }
);
