import fs from 'fs/promises';
import path from 'path';

export async function fileExists(filePath: string) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

export async function fileExistsInProject(filePath: string | undefined) {
  const projectRoot = process.cwd(); // 获取当前工作目录，即项目根目录

  if (filePath === undefined) {
    return false;
  }
  // 组合文件的绝对路径
  const absoluteFilePath = path.resolve(projectRoot, filePath);
  return (
    absoluteFilePath.startsWith(projectRoot) && fileExists(absoluteFilePath)
  );
}
