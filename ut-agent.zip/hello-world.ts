// hello-world.ts
export function helloWorld(): string {
  return 'Hello, World!';
}