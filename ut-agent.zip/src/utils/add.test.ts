// src/utils/add.ts
export function add(a?: number, b?: number): number {
  // Check if both arguments are provided and are numbers
  if (typeof a === 'number' && typeof b === 'number') {
    return a + b;
  } else {
    return NaN;
  }
}