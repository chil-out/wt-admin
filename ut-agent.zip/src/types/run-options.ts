export type Options = {
  outputFile: string;
  promptFile: string;
  testCommand: string;
  testFile: string;
  lastRunError: string;
  priorCode?: string;
  threadId: string;
  prompt?: string;
  interactive?: boolean;
  addedLogs?: boolean;
};

export type RunOptions = Options & {
  maxRuns?: number;
};
