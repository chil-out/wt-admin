// hello-world.test.ts
import { describe, it, expect } from 'vitest';
import { helloWorld } from './hello-world';

describe('helloWorld', () => {
  it('should return "Hello, World!"', () => {
    const result = helloWorld();
    expect(result).toBe('Hello, World!');
  });

  it('should return a string', () => {
    const result = helloWorld();
    expect(typeof result).toBe('string');
  });

  it('should not return an empty string', () => {
    const result = helloWorld();
    expect(result).not.toBe('');
  });

  it('should not return null or undefined', () => {
    const result = helloWorld();
    expect(result).not.toBeNull();
    expect(result).not.toBeUndefined();
  });
});