// add.test.ts
import { describe, it, expect } from 'vitest';
import { add } from './add';

describe('add', () => {
  it('should return the sum of two positive numbers', () => {
    const result = add(2, 3);
    expect(result).toBe(5);
  });

  it('should return the sum of two negative numbers', () => {
    const result = add(-2, -3);
    expect(result).toBe(-5);
  });

  it('should return the sum of a positive and a negative number', () => {
    const result = add(2, -3);
    expect(result).toBe(-1);
  });

  it('should return the sum of zero and another number', () => {
    const result = add(0, 5);
    expect(result).toBe(5);
  });

  it('should return the sum of two zeros', () => {
    const result = add(0, 0);
    expect(result).toBe(0);
  });

  it('should handle large numbers', () => {
    const result = add(1000000, 2000000);
    expect(result).toBe(3000000);
  });

  it('should handle decimal numbers', () => {
    const result = add(1.5, 2.5);
    expect(result).toBe(4);
  });

  it('should return NaN when a non-number is passed', () => {
    const result = add(2, 'a' as any);
    expect(result).toBeNaN();
  });

  it('should return NaN when no arguments are passed', () => {
    const result = add();
    expect(result).toBeNaN();
  });

  it('should return NaN when only one argument is passed', () => {
    const result = add(2);
    expect(result).toBeNaN();
  });
});