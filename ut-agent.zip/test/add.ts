//help me write a simple add method

export const add = (a: number, b: number) => a + b;
